import java.util.*;

public class Main {

    public static void main(String[] args) {

        //1. Created array list called colors and printed out collection
        Scanner scan = new Scanner(System.in);
        ArrayList<String> colors = new ArrayList<>();

        colors.add("Red");
        colors.add("Green");
        colors.add("Yellow");
        colors.add("Black");

        //3. Inserted Element in first Position.
        colors.add(0,"Orange");

        //2. Iterate through all elements in array.
        for (String element : colors) {

            System.out.println("Colors: " + colors);
        }

        //4. Retrieved Element at index 2
        System.out.println("\n Display 3rd element: " + colors.get(2));

        //5. Updated Element
        colors.add(1,"White");
        System.out.println("\n Updated element: "+ colors);

        //6. Removed third element
        colors.remove(2);
        System.out.println("\n Removing 3rd element: "+ colors);

        //7. Program to search for an element
        System.out.println("\n Enter color to search: ");
        String color = scan.next();


        if (colors.contains(color)){
            System.out.println("Color : " + color);
        }else {
            System.out.println("Color does not exist in array!");
        }

        //8. Sorted array
        int [] numbers = {5,2,8,1,4};

        for (int i = 0; i < numbers.length; i++){
            for(int j = 0; j < numbers.length -1; j++) {
                if(numbers[j]> numbers[j + 1]){
                    int temp = numbers[j];
                    numbers[j] = numbers [j + 1];
                    numbers [j+1] = temp;
                }
                System.out.println("\n Sorted Array: " + Arrays.toString(numbers));
            }

        }
        ArrayList<String> Fruit = new ArrayList<>();
        Fruit.add("Grape");
        Fruit.add("Watermelon");
        Fruit.add("Banana");
        Fruit.add("Avocado");
        Fruit.add("Orange");

        System.out.println("Fruits: " +Fruit );

        //10. Shuffle array list
        Collections.shuffle(Fruit);
        System.out.println("\n Shuffled Fruits: " + Fruit);

        //11. Reverse elements in array list
        Collections.reverse(Fruit);
        System.out.println("\n Reversed Fruits: " + Fruit);

        //12. Extracted Portion of an array list
        List<String> Portion = Fruit.subList(1,4);
        System.out.println("\n Portion of Array: " + Portion );

        //13. Compare two array lists
        ArrayList<String> Teams1  = new ArrayList<>();
        Teams1.add("Barcelona");
        Teams1.add("Real Madrid");
        Teams1.add("AC Milan");

        ArrayList<String> Teams2 = new ArrayList<>();
        Teams2.add("Liverpool");
        Teams2.add("Chelsea");
        Teams2.add("Manchester City");

        System.out.println("Teams :" + Teams1 + "\n" +  Teams2);

        if(Teams1.equals(Teams2)){
            System.out.println("\n The two ArrayLists are equal");
        }else{
            System.out.println("\n The two ArrayLists are not equal");
        }

        //14. Swap two elements in array list
        System.out.println("\n Teams 1: "+ Teams1);
        Teams1.set(0,"Arsenal");
        Teams1.set(2,"Bayern Munich");
        System.out.println("\n Swapped Array: " + Teams1 );

        //15. Join two array lists
        Teams1.addAll(Teams2);
        System.out.println("\n Joined Arrays: " + Teams1);

        //17. Empty Array list
        Teams1.removeAll(Teams1);
        System.out.println("\n Emptied Array Team 1: " + Teams1);

        //18. Test whether an array list is empty
        if(Teams1.isEmpty()){
            System.out.println("\n Array is empty");
        }else{
            System.out.println("\n Array is not empty");
        }

        //20. Increase an array list size.
        ArrayList<String> Names = new ArrayList<>(5);
        Names = new ArrayList<>(10);

        //21. Replace the second element of an array list with another specified element.
        System.out.println("\n Teams 2: " + Teams2);
        Teams2.set(1,"Manchester United");
        System.out.println("\n Replaced 2nd element: " + Teams2);




        }





    }

